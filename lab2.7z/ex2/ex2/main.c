#include <avr/io.h>
#define F_CPU 16000000UL
#include "util/delay.h"

#define tByte unsigned char
#define MAX_DIG 10

#define DIG0 0b00111111
#define DIG1 0b00000110
#define DIG2 0b01011011
#define DIG3 0x4f
#define DIG4 0x66
#define DIG5 0x6D
#define DIG6 0x7D
#define DIG7 0x07
#define DIG8 0x7F
#define DIG9 0x6F

const tByte DispTable[] = {
	DIG0,DIG1,DIG2,DIG3,DIG4,DIG5,DIG6,DIG7,DIG8,DIG9
};

volatile tByte i = 0;

void fDispDig(tByte d){
	PORTC = (d&0b00001111);
	PORTD = (d&0b01110000);
}

int main(void)
{	
	DDRC = 0b00001111;
	DDRD = 0b01110000;
	fDispDig(DIG0);
    while (1) 
    {
		if ((PIND&0b10000000)==0){
			i++;
			if (i>=MAX_DIG) i = 0;
			fDispDig(DispTable[i]);
			_delay_ms(150);
		}
    }
}

